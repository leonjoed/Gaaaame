import http.server, functools
class H(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map, ".apk": "application/octet-stream", ".wasm": "application/wasm", ".html": "text/html"}
    def end_headers(self): self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Cache-Control", "no-cache"); super().end_headers()
http.server.ThreadingHTTPServer(("0.0.0.0", 8793), functools.partial(H, directory="/workspace/mech-proto-web/build/web")).serve_forever()
